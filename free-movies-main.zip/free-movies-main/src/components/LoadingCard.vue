<script setup>
    import {VSkeletonLoader} from "vuetify/labs/components";
</script>

<template>
    <v-skeleton-loader class="mx-auto border mt-3" max-width="300" type="image, heading"></v-skeleton-loader>
</template>

<style scoped></style>